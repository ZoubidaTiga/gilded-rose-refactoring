package com.exceptions;

public class InvalidQualityExceptSulfurasException extends Exception {

    public InvalidQualityExceptSulfurasException(String message){
        super(message);
    }
}
