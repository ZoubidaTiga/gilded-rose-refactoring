package com.exceptions;


public class InvalidSulfurasQualityException extends Exception {

    public InvalidSulfurasQualityException(String message){
        super(message);
    }

}
